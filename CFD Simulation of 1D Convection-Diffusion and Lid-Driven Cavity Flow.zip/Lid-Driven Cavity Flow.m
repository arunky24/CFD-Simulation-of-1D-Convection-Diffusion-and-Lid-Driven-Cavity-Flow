% Lid-Driven Cavity Flow Results with Benchmark Data

% Define simulation parameters
Re = [100, 400, 1000];  % Reynolds numbers
N = [129, 129, 129];     % Grid sizes for each Re
L = 1;                        % Domain size
U = 1;                        % Moving lid velocity
rho = 1;                      % Fluid density
dt = 0.001;                   % Time step size
max_iter = 400000;             % Maximum number of iterations
tol = 1e-6;                   % Convergence tolerance

% Simulation loop
for k = 1:length(Re)
    re = Re(k);
    n = N(k);
    fprintf('Running simulation for Re = %d, Grid Size = %dx%d\n', re, n, n);

    % Grid setup
    Nx = n;  
    Ny = n;  
    h = L / (Nx - 1);               % Grid spacing
    x = linspace(0, L, Nx);         % x-coordinates
    y = linspace(0, L, Ny);         % y-coordinates

    % Initialize fields
    sf = zeros(Nx, Ny);             % Stream function
    vort = zeros(Nx, Ny);           % Vorticity
    u = zeros(Nx, Ny);              % x-velocity
    v = zeros(Nx, Ny);              % y-velocity
    mu = rho * U * L / re;          % Dynamic viscosity

    % Iterative solver
    for iter = 1:max_iter
        sf_old = sf;
        vort_old = vort;

        %% Boundary conditions

        % For Stream function
        sf(1, :) = sf(2, :);            % Left wall
        sf(Nx, :) = sf(Nx-1, :);        % Right wall
        sf(:, 1) = sf(:, 2);            % Bottom wall
        sf(:, Ny) = h + sf(:, Ny-1);    % Top wall

        % For Vorticity
        vort(1, :) = (-16 * sf(2, :)) / h^2 - vort(2, :);                    % Left wall
        vort(Nx, :) = (-16 * sf(Nx-1, :)) / h^2 - vort(Nx-1, :);             % Right wall
        vort(:, 1) = (-16 * sf(:, 2)) / h^2 - vort(:, 2);                    % Bottom wall
        vort(:, Ny) = (-16 * sf(:, Ny-1)) / h^2 - (8 / h) - vort(:, Ny-1);   % Top wall

        % Update velocity fields
        u(2:Nx-1, 2:Ny-1) =  (sf(2:Nx-1, 3:Ny) - sf(2:Nx-1, 1:Ny-2)) / (2 * h);
        v(2:Nx-1, 2:Ny-1) = -(sf(3:Nx, 2:Ny-1) - sf(1:Nx-2, 2:Ny-1)) / (2 * h);
        u(:, Ny) = U;  % Lid velocity
        v(:, Ny) = 0;  % No vertical velocity at the lid

        % Update vorticity
        for i = 2:Nx-1
            for j = 2:Ny-1
                conv_x = u(i, j) * (vort(i+1, j) - vort(i-1, j)) / (2 * h);
                conv_y = v(i, j) * (vort(i, j+1) - vort(i, j-1)) / (2 * h);
                diff_x = (vort(i+1, j) - 2 * vort(i, j) + vort(i-1, j)) / h^2;
                diff_y = (vort(i, j+1) - 2 * vort(i, j) + vort(i, j-1)) / h^2;
                vort(i, j) = vort(i, j) + dt * (-conv_x - conv_y + mu / rho * (diff_x + diff_y));
            end
        end

        % Solve for stream function
        for i = 2:Nx-1
            for j = 2:Ny-1
                sf(i, j) = 0.25 * (sf(i+1, j) + sf(i-1, j) + sf(i, j+1) + sf(i, j-1) + h^2 * vort(i, j));
            end
        end

        % Check convergence
        res_sf = max(max(abs(sf - sf_old)));
        res_vort = max(max(abs(vort - vort_old)));
        if mod(iter, 1000) == 0
            fprintf('Iteration: %d, Residual SF: %.5e, Residual VORT: %.5e\n', iter, res_sf, res_vort);
        end
        if res_sf < tol && res_vort < tol
            fprintf('Converged after %d iterations for Re = %d.\n', iter, re);
            break;
        end
    end

    % Benchmark data (exact values for centerline velocities)
    y_data_points = [1.00000, 0.9766, 0.9688, 0.9609, 0.9531, 0.8516, 0.7344, 0.6172, ...
           0.5000, 0.4531, 0.2813, 0.1719, 0.1016, 0.0703, 0.0625, 0.0547, 0.0000];
    u_data_points = {
    [1.00000, 0.84123, 0.78871, 0.73722, 0.68717, 0.23151, 0.00332, -0.13641, ...
    -0.20581, -0.21090, -0.15662, -0.10150, -0.06434, -0.04775, -0.04192, -0.03717, 0.00000]  % Re = 100
    [1.00000, 0.75837, 0.68439, 0.61756, 0.55892, 0.29093, 0.16256, 0.02135, ...
    -0.11477, -0.17119, -0.32726, -0.24299, -0.14612, -0.10338, -0.09266, -0.08186, 0.00000]  % Re = 400
    [1.00000, 0.65928, 0.57492, 0.51117, 0.46604, 0.33304, 0.18719, 0.05702, ...
    -0.06080, -0.10648, -0.27805, -0.38289, -0.29730, -0.22220, -0.20196, -0.18109, 0.00000]  % Re = 1000
    [1.00000, 0.53236, 0.48296, 0.46547, 0.46101, 0.34682, 0.19791, 0.07156, ...
    -0.04272, -0.08636, -0.24427, -0.34323, -0.41933, -0.37827, -0.35344, -0.32407, 0.00000]   % Re = 3200
                    };
    x_data_points = [1.0000, 0.9688, 0.9609, 0.9531, 0.9453, 0.9063, 0.8594, 0.8047, ...
           0.5000, 0.2344, 0.2266, 0.1563, 0.0938, 0.0781, 0.0703, 0.0625, 0.0000];
    v_data_points = {
    [0.00000, -0.05906, -0.07391, -0.08864, -0.10313, -0.16914, -0.22445, -0.24533, ...
    0.05454, 0.17527, 0.17507, 0.16077, 0.12317, 0.10890, 0.10091, 0.09233, 0.00000]   % Re = 100
    [0.00000, -0.12146, -0.15663, -0.19254, -0.22847, -0.23827, -0.44993, -0.38598, ...
    0.05186, 0.30174, 0.30203, 0.28124, 0.22965, 0.20920, 0.19713, 0.18360, 0.00000]   % Re = 400
    [0.00000, -0.21388, -0.27669, -0.33714, -0.39188, -0.51550, -0.42665, -0.31966, ...
    0.02526, 0.32235, 0.33075, 0.37095, 0.32627, 0.30353, 0.29012, 0.27485, 0.00000]   % Re = 1000
    [0.00000, -0.39017, -0.47425, -0.52357, -0.54053, -0.44307, -0.37401, -0.31184, ...
    -0.00999, 0.28188, 0.29030, 0.37119, 0.42768, 0.41906, 0.40917, 0.39560, 0.00000]    % Re = 3200
                    };

    % Plot: Streamlines
    [X, Y] = meshgrid(x, y);
    figure;
    startx = linspace(0, L, 30);
    starty = linspace(0, L, 30);
    h_stream = streamslice(X, Y, u', v', 2);
    set(h_stream, 'LineWidth', 1, 'Color', 'b');
    title(sprintf('Streamlines for Re=%d', re), 'FontSize', 14);
    xlabel('x', 'FontSize', 12);
    ylabel('y', 'FontSize', 12);
    axis equal tight;

    % Plot: Velocity profiles with exact data
    figure;

    % v-velocity profile at x = 0.5
    subplot(2, 1, 1);
    [~, idx_x_half] = min(abs(x - 0.5));
    v_prof = v(idx_x_half, 2:Ny-1);
    plot(y(2:Ny-1), v_prof, 'b-', 'LineWidth', 2);
    hold on;
    plot(y_data_points, v_data_points{k}, 'ko', 'LineWidth', 1.5); % Exact data
    xlabel('y'); ylabel('v velocity'); grid on;
    legend('Computed', 'Exact');
    title(sprintf('v vs y at x=0.5 for Re=%d', re));

    % u-velocity profile at y = 0.5
    subplot(2, 1, 2);
    [~, idx_y_half] = min(abs(y - 0.5));
    u_prof = u(2:Nx-1, idx_y_half);
    plot(x(2:Nx-1), u_prof, 'r-', 'LineWidth', 2);
    hold on;
    plot(x_data_points, u_data_points{k}, 'ko', 'LineWidth', 1.5); % Exact data
    xlabel('x'); ylabel('u velocity'); grid on;
    legend('Computed', 'Exact');
    title(sprintf('u vs x at y=0.5 for Re=%d', re));
end