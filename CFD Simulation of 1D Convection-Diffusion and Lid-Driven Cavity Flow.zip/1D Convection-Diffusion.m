% Parameters
Re_values = [10, 50];      % Reynolds numbers to simulate
x_max = 1.0;               % Spatial domain extent
Nx = 101;                  % Number of spatial points
dx = 2 * x_max / (Nx - 1); % Spatial step size
x = linspace(-x_max, x_max, Nx); % Spatial grid
T = 1;                     % Final time
dt = 0.001;                % Time step size
Nt = T / dt;               % Number of time steps
U0_left = 1.0;             % Boundary condition at x = -x_max
U0_right = 0.0;            % Boundary condition at x = x_max

% Initial condition based on the problem statement
U_init = @(x) (x <= 0) * U0_left + (x > 0) * U0_right;
initial_U = U_init(x);

% Calculate maximum velocity for CFL condition
U_max = max(initial_U);

% CFL condition check for explicit scheme
CFL_explicit = zeros(size(Re_values)); % Preallocate for CFL values
for i = 1:length(Re_values)
    CFL_explicit(i) = U_max * dt / dx + dt / (Re_values(i) * dx^2);
    fprintf('CFL condition for Re = %d: %.4f\n', Re_values(i), CFL_explicit(i));
end

if any(CFL_explicit > 1)
    fprintf('Warning: CFL condition not satisfied for explicit scheme!\n');
    dt = min(dt, 0.5 * dx / U_max); % Adjust dt to satisfy CFL
    fprintf('Adjusted dt to: %.6f\n', dt);
    Nt = round(T / dt);  % Recalculate number of time steps based on new dt
end

% Exact solution function
exact_solution = @(x, t, Re, U0_left, U0_right, x_max) ...
    arrayfun(@(xi) compute_exact(xi, t, Re, U0_left, U0_right, x_max), x);

% Exact solution computation (integral form)
function u_exact = compute_exact(x, t, Re, U0_left, U0_right, x_max)
    integrand = @(xi) exp(-Re * ((x - xi).^2) / (4 * t)) .* ((xi <= 0) * U0_left + (xi > 0) * U0_right);
    numerator = integral(integrand, -x_max, x_max, 'ArrayValued', true);
    denominator = integral(@(xi) exp(-Re * ((x - xi).^2) / (4 * t)), -x_max, x_max, 'ArrayValued', true);
    u_exact = numerator / denominator;
end

% Explicit scheme
function U_new = explicit_scheme(U, dx, dt, Re)
    Nx = length(U);
    U_new = U;
    for i = 2:Nx-1
        convective_term = U(i) * (U(i+1) - U(i-1)) / (2 * dx);
        diffusive_term = (U(i+1) - 2 * U(i) + U(i-1)) / dx^2;
        U_new(i) = U(i) - dt * convective_term + dt * diffusive_term / Re;
    end
end

% Thomas algorithm for solving tridiagonal systems
function u = thomas_algorithm(a, b, c, d)
    N = length(b); % Number of equations
    c_prime = zeros(N, 1);
    d_prime = zeros(N, 1);
    c_prime(1) = c(1) / b(1);
    d_prime(1) = d(1) / b(1);
    for i = 2:N-1
        m = 1 / (b(i) - a(i) * c_prime(i-1));
        c_prime(i) = c(i) * m;
        d_prime(i) = (d(i) - a(i) * d_prime(i-1)) * m;
    end
    d_prime(N) = (d(N) - a(N) * d_prime(N-1)) / (b(N) - a(N) * c_prime(N-1));
    u = zeros(N, 1);
    u(N) = d_prime(N);
    for i = N-1:-1:1
        u(i) = d_prime(i) - c_prime(i) * u(i+1);
    end
end

% Implicit scheme with Thomas algorithm
function U_implicit = implicit_scheme(U_init, dx, dt, Re, Nt, U0_left, U0_right)
    nx = length(U_init);
    U_implicit = zeros(nx, Nt + 1);
    U_implicit(:, 1) = U_init;
    alpha = dt / (Re * dx^2);
    beta = dt / (2 * dx);

    for n = 1:Nt
        a = zeros(nx, 1);
        b = ones(nx, 1) + 2 * alpha;
        c = zeros(nx, 1);
        d = U_implicit(:, n);

        d(1) = U0_left;
        d(nx) = U0_right;

        for i = 2:nx-1
            u_i = U_implicit(i, n);
            a(i) = -beta * u_i - alpha;
            b(i) = 1 + 2 * alpha;
            c(i) = beta * u_i - alpha;
        end

        U_implicit(:, n+1) = thomas_algorithm(a, b, c, d);
    end
end

% Crank-Nicolson scheme with Thomas algorithm
function U_cn = crank_nicolson_scheme(U_init, dx, dt, Re, Nt, U0_left, U0_right)
    nx = length(U_init);
    U_cn = zeros(nx, Nt + 1);
    U_cn(:, 1) = U_init;
    alpha = dt / (2 * Re * dx^2);

    % Define the tridiagonal matrix coefficients for matrix A
    a = -alpha * ones(nx, 1); % sub-diagonal coefficients
    b = (1 + 2 * alpha) * ones(nx, 1); % main diagonal coefficients
    c = -alpha * ones(nx, 1); % super-diagonal coefficients

    % Adjust the boundary conditions in matrix A
    b(1) = 1; a(1) = 0; c(1) = 0; % Left boundary
    b(nx) = 1; a(nx) = 0; c(nx) = 0; % Right boundary

    % Matrix B (right-hand side of the Crank-Nicolson scheme)
    B = diag(1 - 2 * alpha * ones(1, nx)) + diag(alpha * ones(1, nx-1), 1) + diag(alpha * ones(1, nx-1), -1);

    for n = 1:Nt
        % Calculate the right-hand side vector `d`
        d = B * U_cn(:, n);

        % Apply boundary conditions to the right-hand side vector
        d(1) = U0_left;
        d(nx) = U0_right;

        % Solve the tridiagonal system A * U_cn(:, n+1) = d using Thomas algorithm
        U_cn(:, n+1) = thomas_algorithm(a, b, c, d);
    end
end

% Simulation and Animation Function
for Re = Re_values
    fprintf('Solving for Re = %d\n', Re);
    
    % Calculate exact solution
    U_exact = zeros(Nt + 1, Nx);
    for i = 1:Nt + 1
        U_exact(i, :) = exact_solution(x, (i-1)*dt, Re, U0_left, U0_right, x_max);
    end
    
    % Run explicit scheme
    U_explicit = zeros(Nt + 1, Nx);
    U_explicit(1, :) = initial_U;
    for n = 1:Nt
        U_explicit(n+1, :) = explicit_scheme(U_explicit(n, :), dx, dt, Re);
        U_explicit(n+1, 1) = U0_left;
        U_explicit(n+1, end) = U0_right;
    end

    % Run implicit scheme
    U_implicit = implicit_scheme(initial_U, dx, dt, Re, Nt, U0_left, U0_right);
    
    % Run Crank-Nicolson scheme
    U_cn = crank_nicolson_scheme(initial_U, dx, dt, Re, Nt, U0_left, U0_right);

    % Animation for all solutions
    figure;
    num_frames = 60; % Set the number of frames for 1 second
    pause_time = 1 / num_frames; % Time per frame

    for n = 1:round(Nt/num_frames):Nt+1

        % Plot for Exact
        subplot(4,1,1);
        cla;
        plot(x, U_exact(n,:), 'k-', 'LineWidth', 1.5);
        title(sprintf('Exact Solution (Re=%d, t=%.3f)', Re, (n-1)*dt));
        xlabel('x'); ylabel('u'); grid on;
        
        % Plot for Explicit Scheme
        subplot(4,1,2);
        cla;
        plot(x, U_exact(n,:), 'k-', 'LineWidth', 1.5); % Exact solution
        hold on; % Hold the current plot
        plot(x, U_explicit(n,:), 'b-', 'LineWidth', 1.5); % Explicit solution
        title(sprintf('Explicit Scheme (Re=%d, t=%.3f)', Re, (n-1)*dt));
        xlabel('x'); ylabel('u'); grid on;
        legend('Exact Solution', 'Explicit Scheme');

        % Plot for Implicit Scheme
        subplot(4,1,3);
        cla;
        plot(x, U_exact(n,:), 'k-', 'LineWidth', 1.5); % Exact solution
        hold on; % Hold the current plot
        plot(x, U_implicit(:,n), 'r-', 'LineWidth', 1.5); % Implicit solution
        title(sprintf('Implicit Scheme (Re=%d, t=%.3f)', Re, (n-1)*dt));
        xlabel('x'); ylabel('u'); grid on;
        legend('Exact Solution', 'Implicit Scheme');

        % Plot for Crank-Nicolson Scheme
        subplot(4,1,4);
        cla;
        plot(x, U_exact(n,:), 'k-', 'LineWidth', 1.5); % Exact solution
        hold on; % Hold the current plot
        plot(x, U_cn(:,n), 'g-', 'LineWidth', 1.5); % Crank-Nicolson solution
        title(sprintf('Crank-Nicolson Scheme (Re=%d, t=%.3f)', Re, (n-1)*dt));
        xlabel('x'); ylabel('u'); grid on;
        legend('Exact Solution', 'Crank-Nicolson Scheme');

        pause(pause_time); % Pause for the calculated time for 1 second animation
    end
end
